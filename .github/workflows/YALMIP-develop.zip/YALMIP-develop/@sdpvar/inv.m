function varargout=inv(varargin)
%INV

disp('INV is not defined on general SDPVAR objects')
disp('https://yalmip.github.io/faq/inverse/')
