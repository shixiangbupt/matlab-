function n=ndims(X)
%NDIM (overloaded)

n = length(X.dim);